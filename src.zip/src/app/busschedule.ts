export class BusSchedule{
    name: string;
    leavetime:string;
    arrivetime:string;
}