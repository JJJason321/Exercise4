import { Component, OnInit } from '@angular/core';
import {BusSchedule} from '../busschedule';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  CarProperty:string = "car";

  list = ['car','bus'];

  schedule: BusSchedule[] = [{name:"101",arrivetime:"10:00", leavetime:"11:00"},
  {name:"202", arrivetime:"12:00",leavetime:"13:00"}];
  


  constructor() { }

  ngOnInit() {
   
  }

}
